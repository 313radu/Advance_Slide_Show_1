"use strict";

const body = document.body;
let onLoad = document.getElementById("onLoad");
const loadContainer = document.querySelector(".on-load-picture-container");
const loadContainerWidth = loadContainer.clientWidth;
 
body.onload = function() {
    gsap.from('.pic1', {duration: .8, delay: 1, x: loadContainerWidth / 2.5 , ease: 'linear'});
    gsap.from('.pic2', {duration: .8, delay: 1, x: loadContainerWidth / 7.5 , ease: 'linear' });
    gsap.from('.pic3', {duration: .8, delay: 1, x: -loadContainerWidth / 7.5 , ease:'linear'});
    gsap.from('.pic4', {duration: .8, delay: 1, x: -loadContainerWidth / 2.5 , ease: 'linear'});

function animateLandingPage() { 
    gsap.from(".navbar", {duration: 1.2, y: -150, opacity: 0, ease: "ease-in"});
    gsap.from(".prev-button", {duration: 1, opacity: 0});
    gsap.from(".next-button", {duration: 1, ease: "all", opacity: 0});
    gsap.from(".picture-descript",{duration: 1.4, y: 70, ease:"ease-in"});
}
setTimeout(animateLandingPage, 3400);


const mainPicture = document.getElementsByClassName("main-picture");

function arrangePicture(){
mainPicture[0].classList.add("main-picture1");
mainPicture[1].classList.add("main-picture2");
mainPicture[2].classList.add("main-picture3");
mainPicture[3].classList.add("main-picture4");
}
setInterval(arrangePicture, 3400);

function removeOnLoadPage() { 
    onLoad.classList.add("on-load-out");
}
setInterval(removeOnLoadPage, 3400);
}

const forwardPicture = document.querySelectorAll(".picture-transit");
const nextButton = document.getElementById("nextButton");
let counter = 1;
const pictureDescription = document.getElementById("pictureDescript");

 
// Next Button  ... when it is clicked the picture will be slide forward
nextButton.addEventListener("click", function() {
     
    if(counter == 1) { 
        forwardPicture[3].style.transform = "translateY(-900px) translateX(800px)";
        forwardPicture[2].style.transform = "rotateZ(-14deg)";
        pictureDescription.innerHTML = "Fashion";
        body.style.backgroundColor = "rgb(169, 120, 41)";
     } else if(counter == 2){
        forwardPicture[2].style.transform = "translateY(-900px) translateX(800px)";
        forwardPicture[1].style.transform = "rotateZ(-12deg)";
        pictureDescription.innerHTML = "Portraits";
        body.style.backgroundColor = "rgb(223, 107, 61)";
     } else if(counter == 3 ){
        forwardPicture[1].style.transform = "translateY(-900px) translateX(800px)";
        forwardPicture[0].style.transform = "rotateZ(-20deg)";
        pictureDescription.innerHTML = "Design";
        body.style.backgroundColor = "indigo";
    } else if(counter <= 4) {
        return counter;
    }
    counter++;
 });

//  Prev Button ... when it is clickrd the picture will be slide backward
 const prevButton = document.getElementById("prevButton");
 prevButton.addEventListener("click", function() {
    
    if(counter == 5){ 
        forwardPicture[0].style.transform = "translateY(0) translateX(0) rotateZ(-8deg)";
        pictureDescription.innerHTML = "Design";
        body.style.backgroundColor = "rgb(223, 107, 61)";
    } else if(counter == 4){ 
        forwardPicture[1].style.transform = "translateY(0) translateX(0) rotateZ(-1deg)";
        pictureDescription.innerHTML = "Portraits";
        body.style.backgroundColor = "rgb(223, 107, 61)";
    }else if(counter == 3) { 
        forwardPicture[2].style.transform = "translateY(0) translateX(0) rotateZ(-8deg)";
        pictureDescription.innerHTML = "Fashion";
        body.style.backgroundColor = "rgb(169, 120, 41)";
    }else if(counter == 2) {
        forwardPicture[3].style.transform = "translateY(0) translateX(0) rotateZ(-13deg)";
        pictureDescription.innerHTML = "ArtWork";
        body.style.backgroundColor = "#333";
    } else {
    return counter;
}
    counter--;
 });
 
    
     
 